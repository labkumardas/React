import React from 'react'

function Pagination() {
    return (

        <nav aria-label="...">
            <ul class="pagination">
                <li class="page-item disabled">
                    <a class="page-link" Link to="/" tabindex="-1">Previous</a>
                </li>
                <li class="page-item"><a class="page-link" Link to="/">1</a></li>
                <li class="page-item active">
                    <a class="page-link" Link to="/">2 <span class="sr-only">(current)</span></a>
                </li>
                <li class="page-item"><a class="page-link" Link to="/">3</a></li>
                <li class="page-item">
                    <a class="page-link" Link to="/">Next</a>
                </li>
            </ul>
        </nav>

    )
}

export default Pagination

import React from 'react'
const styleObject  = {
  marginTop: '20%', 
};
function Footer() {
  return (
    <div className="container text-center">
      <div className='row' style={styleObject}>
        <div className="col">
          <div class="card"  >
            <div class="card-body">
              <h3 class="card-title">Footer1</h3>

            </div>
          </div>
        </div>
        <div className="col">
          <div class="card"  >
            <div class="card-body">
              <h3 class="card-title">Footer2</h3>

            </div>
          </div>
        </div>
        <div className="col">
          <div class="card"  >
            <div class="card-body">
              <h3 class="card-title">Footer3</h3>

            </div>
          </div>
        </div>
      </div>

    </div>
  )
}

export default Footer

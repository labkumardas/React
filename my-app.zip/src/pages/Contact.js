import React from 'react'
import Form from '../component/Form'

function Contact() {
    return (
        <div className='container'>
            <div className='row'>
                <div className='col-md-8'>
                <Form />
                </div>
               
            </div>

        </div>
    )
}

export default Contact

import React  from 'react';
import images from "../const/Imagepath.js";

console.log(images, "images");
function Home() {
  return (
    <div className="container text-center">
      <div className='row'>
        <div id="carouselExample" className="carousel slide">
          <div className="carousel-inner">

            <div className="carousel-item active">
              <img src={images.banner} className="d-block w-100" alt="banner1" />
            </div>

            <div className="carousel-item">
              <img src={images.banner} className="d-block w-100" alt="banner2" />
            </div>

            <div className="carousel-item">
              <img src={images.banner} className="d-block w-100" alt="banner3" />
            </div>

          </div>
          <button className="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
            <span className="carousel-control-prev-icon" aria-hidden="true"></span>
            <span className="visually-hidden">Previous</span>
          </button>
          <button className="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
            <span className="carousel-control-next-icon" aria-hidden="true"></span>
            <span className="visually-hidden">Next</span>
          </button>
        </div>
      </div>
      <div className="row">
        <div className="col">
          <div className="card"  >
            <img src={images.card} className="card-img-top" alt="card1" />
            <div className="card-body">
              <h5 className="card-title">Card title</h5>
              <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              <a useRef="/" className="btn btn-primary">Go somewhere</a>
            </div>
          </div>
        </div>
        <div className="col">  <div className="card"  >
          <img src={images.card} className="card-img-top" alt="card1" />
          <div className="card-body">
            <h5 className="card-title">Card title</h5>
            <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <a useRef="/" className="btn btn-primary">Go somewhere</a>
          </div>
        </div></div>
        <div className="col">  <div className="card"  >
          <img src={images.card} className="card-img-top" alt="card1" />
          <div className="card-body">
            <h5 className="card-title">Card title</h5>
            <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <a useRef="/" className="btn btn-primary">Go somewhere</a>
          </div>
        </div></div>
        <div className="col">  <div className="card"  >
          <img src={images.card} className="card-img-top" alt="card1" />
          <div className="card-body">
            <h5 className="card-title">Card title</h5>
            <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <a useRef="/" className="btn btn-primary">Go somewhere</a>
          </div>
        </div></div>
      </div>

    </div>
  )
}
export default Home